<?php
session_start();

if(!isset($_SESSION['theme'])) {
	header('Location:select.php');
	exit();
}

$theme = 		$_SESSION['theme'];
session_write_close();

$cssfile = 		"css".$theme.".css";

?>

<html>
<head>
<link rel="stylesheet" href="<?php echo "$cssfile"?>"></link>
</head>
<body>
<h3>page 1</h3>
<p class="copy">(c) 2010 pedro moreira</p>
<p><a href="content2.php">|page 2|</a> - <a href="select.php">|go home|</a></p>

</body>
</html>