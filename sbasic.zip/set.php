<?php
session_start();

if(isset($_SESSION['theme'])) {
	header('Location:select.php');
	exit();
}

if(!isset($_POST['ftheme'])) {
	header('Location:select.php');
	exit();
}

$_SESSION['theme'] = $_POST['ftheme'];

session_write_close();
header('Location:select.php');
?>

