<?php
session_start();
unset($_SESSION['theme']);
unset($_SESSION['nick']);
session_destroy();
header('Location:select.php');
?>